module example.org/oink-table-repro

go 1.27.0

require github.com/pgsty/oink v1.2.0
