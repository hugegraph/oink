---
title: "技术参数表可读性"
type: docs
outputs: [HTML, markdown, print]
---

使用 HugeGraph 示例的原生 OINK 表格，不加载 HugeGraph 模板、Hooks 或样式。

## 配置参数 {#parameters}

| config option        | default value       | description                                                                                                                                                                                                                                                                                                                                       |
|----------------------|---------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| rocksdb.data_path    | `rocksdb-data/data` | RocksDB 数据存储路径，不允许为空。                                                                                                                                                                                                                                                                                                                |
| rocksdb.data_disks   | `[]`                | 为部分表指定独立磁盘，每个元素格式为 `STORE/TABLE: /path/disk`。允许的键为 [g/vertex, g/edge_out, g/edge_in, g/vertex_label_index, g/edge_label_index, g/range_int_index, g/range_float_index, g/range_long_index, g/range_double_index, g/secondary_index, g/search_index, g/shard_index, g/unique_index, g/olap]。磁盘路径不能与 `rocksdb.data_path` 相同。 |
| rocksdb.wal_path     | `rocksdb-data/wal`  | RocksDB WAL 存储路径，不允许为空。                                                                                                                                                                                                                                                                                                                |
| rocksdb.sst_path     | （空）              | 待导入 RocksDB 的 SST 文件所在路径，为空表示不导入。                                                                                                                                                                                                                                                                                              |
| rocksdb.log_level    | `INFO`              | RocksDB 的日志级别，可选值：DEBUG、INFO、WARN、ERROR、FATAL、HEADER。                                                                                                                                                                                                                                                                             |
{#configuration-parameters}

## PD 环境变量 {#environment}

| 变量 | 必填 | 默认值 | 对应配置项 | 描述 |
|------|------|--------|------------|------|
| `HG_PD_GRPC_HOST` | 是 | 无 | `grpc.host` | 本节点对外公布的 gRPC 主机名/IP；容器网络中应使用容器主机名。 |
| `HG_PD_RAFT_ADDRESS` | 是 | 无 | `raft.address` | 本节点 Raft 地址。 |
| `HG_PD_RAFT_PEERS_LIST` | 是 | 无 | `raft.peers-list` | 所有 PD 节点的 Raft 地址，含本节点。 |
| `HG_PD_INITIAL_STORE_LIST` | 是 | 无 | `pd.initial-store-list` | 预期的 Store gRPC 地址。 |
| `HG_PD_AUTH_SECRET_KEY` | 是 | 无 | `auth.secret-key` | REST Basic 密码；所有 PD REST 客户端都必须使用同一密钥。 |
| `HG_PD_GRPC_PORT` | 否 | `8686` | `grpc.port` | gRPC 服务端口。 |
| `HG_PD_REST_PORT` | 否 | `8620` | `server.port` | REST API 端口。 |
| `HG_PD_DATA_PATH` | 否 | `/hugegraph-pd/pd_data` | `pd.data-path` | 元数据存储路径。 |
| `HG_PD_INITIAL_STORE_COUNT` | 否 | `1` | `pd.initial-store-count` | 集群可用所需的最小 Store 数量。 |
| `HG_PD_ACTUATOR_EXPOSURE` | 否 | `health,metrics,prometheus` | `management.endpoints.web.exposure.include` | 公开的 Actuator 端点白名单；不允许设置为 `*`。 |
{#environment-variables}

## Short table {#short-table}

| Component | Port | Purpose |
| --- | --- | --- |
| Server | 8080 | Graph API |
| PD | 8686 | Metadata |
{#short-example}

## Long prose {#long-prose}

| Parameter | Description |
| --- | --- |
| ordinary.option | This description deliberately repeats normal prose to check that the fix does not turn an ordinary table into an unnecessarily long horizontal reading strip. This description deliberately repeats normal prose to check that the fix does not turn an ordinary table into an unnecessarily long horizontal reading strip. |
{#prose-example}

## Long tokens {#long-tokens}

| Parameter | Description |
| --- | --- |
| `longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_long` | An unusually long key must wrap within its own cell without covering this description. |
| [https://example.org/longsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlong](https://example.org/) | Long link labels use the same emergency wrapping. |
{#long-token-example caption="Long identifiers and links"}

## Matrix {#matrix}

| Feature | Linux | macOS | Windows | Documentation | Status |
| --- | --- | --- | --- | --- | --- |
| longFeature_longFeature_longFeature_longFeature_longFeature_longFeature_longFeature_longFeature_longFeature_longFeature_longFeature_longFeature_longFeature_longFeature_longFeature_long | yes | yes | yes | available | supported |
| Standard behavior | yes | yes | yes | available | supported |
{#matrix-example .matrix}

## Full-width table {#full-width}

| Setting | Default | Description |
| --- | --- | --- |
| a.long.configuration.key | enabled | A full-width table continues to use its author's table modifier. |
{#full-width-example .full-width caption="Author-selected full width"}

## Spanning header {#spanning-header}

<div class="td-table-scroll"><table id="spanning-example"><caption>Spanning columns</caption><thead><tr><th colspan="2">Configuration details with a spanning header</th></tr></thead><tbody><tr><td>configuration.key</td><td>A plain HTML table with a spanning header retains the expected column geometry.</td></tr></tbody></table></div>
