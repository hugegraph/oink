---
title: "Technical table readability"
type: docs
outputs: [HTML, markdown, print]
---

Native OINK tables using HugeGraph examples. No HugeGraph layouts, hooks, or styles are loaded.

## Configuration parameters {#parameters}

| config option        | default value       | description                                                                                                                                                                                                                                                                                                                                       |
|----------------------|---------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| rocksdb.data_path    | `rocksdb-data/data` | The path for storing data of RocksDB. Must not be empty.                                                                                                                                                                                                                                                                                          |
| rocksdb.data_disks   | `[]`                | The optimized disks for storing data of RocksDB. The format of each element: `STORE/TABLE: /path/disk`. Allowed keys are [g/vertex, g/edge_out, g/edge_in, g/vertex_label_index, g/edge_label_index, g/range_int_index, g/range_float_index, g/range_long_index, g/range_double_index, g/secondary_index, g/search_index, g/shard_index, g/unique_index, g/olap]. A disk path must differ from `rocksdb.data_path`. |
| rocksdb.wal_path     | `rocksdb-data/wal`  | The path for storing WAL of RocksDB. Must not be empty.                                                                                                                                                                                                                                                                                           |
| rocksdb.sst_path     | (empty)             | The path for ingesting SST file into RocksDB. Empty disables ingestion.                                                                                                                                                                                                                                                                           |
| rocksdb.log_level    | `INFO`              | The info log level of RocksDB. Allowed values: DEBUG, INFO, WARN, ERROR, FATAL, HEADER.                                                                                                                                                                                                                                                            |
{#configuration-parameters}

## PD environment variables {#environment}

| Variable | Required | Default | Configuration key | Description |
|------|------|--------|------------|------|
| `HG_PD_GRPC_HOST` | Yes | None | `grpc.host` | Advertised gRPC hostname/IP; use container hostnames within a container network. |
| `HG_PD_RAFT_ADDRESS` | Yes | None | `raft.address` | This PD node's Raft address. |
| `HG_PD_RAFT_PEERS_LIST` | Yes | None | `raft.peers-list` | Raft addresses of every PD node, including this node. |
| `HG_PD_INITIAL_STORE_LIST` | Yes | None | `pd.initial-store-list` | Expected Store gRPC addresses. |
| `HG_PD_AUTH_SECRET_KEY` | Yes | None | `auth.secret-key` | REST Basic password shared by all PD REST clients. |
| `HG_PD_GRPC_PORT` | No | `8686` | `grpc.port` | gRPC service port. |
| `HG_PD_REST_PORT` | No | `8620` | `server.port` | REST API port. |
| `HG_PD_DATA_PATH` | No | `/hugegraph-pd/pd_data` | `pd.data-path` | Metadata path. |
| `HG_PD_INITIAL_STORE_COUNT` | No | `1` | `pd.initial-store-count` | Minimum Store count needed for cluster availability. |
| `HG_PD_ACTUATOR_EXPOSURE` | No | `health,metrics,prometheus` | `management.endpoints.web.exposure.include` | Public Actuator endpoint allowlist; `*` is forbidden. |
{#environment-variables}

## Short table {#short-table}

| Component | Port | Purpose |
| --- | --- | --- |
| Server | 8080 | Graph API |
| PD | 8686 | Metadata |
{#short-example}

## Long prose {#long-prose}

| Parameter | Description |
| --- | --- |
| ordinary.option | This description deliberately repeats normal prose to check that the fix does not turn an ordinary table into an unnecessarily long horizontal reading strip. This description deliberately repeats normal prose to check that the fix does not turn an ordinary table into an unnecessarily long horizontal reading strip. |
{#prose-example}

## Long tokens {#long-tokens}

| Parameter | Description |
| --- | --- |
| `longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_longidentifier_long` | An unusually long key must wrap within its own cell without covering this description. |
| [https://example.org/longsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlongsegmentlong](https://example.org/) | Long link labels use the same emergency wrapping. |
{#long-token-example caption="Long identifiers and links"}

## Matrix {#matrix}

| Feature | Linux | macOS | Windows | Documentation | Status |
| --- | --- | --- | --- | --- | --- |
| longFeature_longFeature_longFeature_longFeature_longFeature_longFeature_longFeature_longFeature_longFeature_longFeature_longFeature_longFeature_longFeature_longFeature_longFeature_long | yes | yes | yes | available | supported |
| Standard behavior | yes | yes | yes | available | supported |
{#matrix-example .matrix}

## Full-width table {#full-width}

| Setting | Default | Description |
| --- | --- | --- |
| a.long.configuration.key | enabled | A full-width table continues to use its author's table modifier. |
{#full-width-example .full-width caption="Author-selected full width"}

## Spanning header {#spanning-header}

<div class="td-table-scroll"><table id="spanning-example"><caption>Spanning columns</caption><thead><tr><th colspan="2">Configuration details with a spanning header</th></tr></thead><tbody><tr><td>configuration.key</td><td>A plain HTML table with a spanning header retains the expected column geometry.</td></tr></tbody></table></div>
