module example.org/oink-footer-repro

go 1.27.0

require github.com/pgsty/oink v1.2.0
